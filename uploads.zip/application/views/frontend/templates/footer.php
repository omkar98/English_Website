<section class = "section-footer">
	<div class = "container">
		<div class = "row">
			<div class = "col-md-8">
				<h5>Copyright &copy; 2019 by English Guru</h5>
			</div>
			<div class = "col-md-4">
				<h5><i class = "fa fa-facebook"></i> <i class = "fa fa-youtube"><i class = "fa fa-instagram"></i></i></h5>
			</div>
		</div>
	</div>
</section>
</body>
</html>
